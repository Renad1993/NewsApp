# NewsApp

This app use secret api-key so any one use this code must replace this api-key with a key belonging to that person
or use "test" api-key ...